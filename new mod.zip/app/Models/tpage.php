<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tpage extends Model
{
    use HasFactory;
    protected $fillable=['titre','description','titre1','description1'];

}
