<section id="loading">
				<span></span>
</section>
<div class="container-logo-navigation top-fixed">
   <div class="logo">
      <a href="./"><img src="assets/img/logo-vertical.png" alt=""></a>
   </div>
   <div class="container-navigation">
      <ul>
         <li>
           <a href="a-propos.php">
             <!-- <svg>
              <rect x="0" y="0" fill="none" width="100%" height="100%"></rect>
            </svg> -->
             A propos
           </a>
         </li>
         <li><a class="active" href="service.php">Services</a></li>
         <li><a href="projet.php">Projets</a></li>
         <li><a href="#!">Terrains</a></li>
         <li><a href="#!">Maisons virtuelles</a></li>
         <li><a href="blog.php">Actualités</a></li>
         <li><a href="brochure.php">Brochure</a></li>
      </ul>
   </div>
</div>
<div class="container-logo-navigation top-fixed" id="responsive-mode" style="display:none">
   <div class="logo">
      <a href="./"><img src="assets/img/logo.png" alt=""></a>
   </div>
   <div class="container-navigation">
            <div class="content-btn-responsive">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
      <ul>
         <li>
           <a href="a-propos.php">
             <!-- <svg>
              <rect x="0" y="0" fill="none" width="100%" height="100%"></rect>
            </svg> -->
             A propos
           </a>
         </li>
         <li><a class="active" href="service.php">Services</a></li>
         <li><a href="projet.php">Projets</a></li>
         <li><a href="#!">Terrains</a></li>
         <li><a href="#!">Maisons virtuelles</a></li>
         <li><a href="blog.php">Actualités</a></li>
         <li><a href="brochure.php">Brochure</a></li>
      </ul>
   </div>
</div>
