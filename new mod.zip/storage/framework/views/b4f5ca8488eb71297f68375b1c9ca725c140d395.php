<footer class="footer pb-4">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-muted text-lg-left">
                    Copyright © bsTech <?php echo e(now()->year); ?> <br> Soft by <a style="color: #252f40;" href="mailto:brondonstyve@gmail.com" class="font-weight-bold ml-1"
                        target="_blank">brondon styve Team</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/styve/dev/laravel/batipro/resources/views/layouts/footers/auth/footer.blade.php ENDPATH**/ ?>