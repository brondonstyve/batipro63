    <main>
      <div class="container-fluid py-4">
       
        <?php echo $__env->make('components.tables.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </main>
<?php /**PATH /home/styve/dev/laravel/batipro/resources/views/livewire/tables.blade.php ENDPATH**/ ?>