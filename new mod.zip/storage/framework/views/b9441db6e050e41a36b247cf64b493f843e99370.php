<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <div>


        <table style="background-color:#444;width:100%" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td style="padding:20px;text-align:center;font-family:sans-serif;color:#fff;font-size:28px">
                        Batipro63
                    </td>
                </tr>
            </tbody>
        </table>


        <table style="background-color:#eee;width:100%">
            <tbody>
                <tr>
                    <td align="center" style="padding:15px">


                        <table style="background-color:#fff;max-width:600px;width:100%;border:1px solid #ddd">
                            <tbody>
                                <tr>
                                    <td style="padding:15px;color:#333;font-size:16px;font-family:sans-serif">



                                        <p>Bonjour,</p>
                                        <p>Nous vous remercions d'avoir visité notre site internet <a href="http://batipro63.fr" rel="nofollow noopener noreferrer nofollow noopener noreferrer" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://batipro63.fr&amp;source=gmail&amp;ust=1641478464356000&amp;usg=AOvVaw1kR--KcD1JaUna7w3PtsoP">batipro63.fr</a></p>
                                        <p>Suite à la demande que vous avez effectué sur notre site, veuillez trouvez ci-après la page de téléchargement de notre catalogue : <a href="<?php echo e(route('down')); ?>" rel="nofollow noopener noreferrer nofollow noopener noreferrer"
                                                target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://batipro63.fr/telechargement/&amp;source=gmail&amp;ust=1641478464356000&amp;usg=AOvVaw3mJMnkgJv2KQRmUkZjAhUp">Télécharger le catalogue</a></p>
                                        <p>Vous pourrez découvrir nos différentes maisons modernes et contemporaines, ainsi que les services et garanties que nous fournissons.</p>
                                        <p>Si vous souhaitez un devis personnélisé, nous vous invitons à nous contacter via notr site <a href="http://batipro63.fr" rel="nofollow noopener noreferrer nofollow noopener noreferrer" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://batipro63.fr&amp;source=gmail&amp;ust=1641478464356000&amp;usg=AOvVaw1kR--KcD1JaUna7w3PtsoP">batipro63.fr</a></p>
                                        <p>Très cordialement,</p>
                                        <p>L'équipe Batipro63</p>
                                        <p>Tél. : 04 73 31 23 97 - <a href="mailto:contact@batipro63.fr" target="_blank">contact@batipro63.fr</a></p>

                                        <hr>

                                        <p>
                                            <small>
                                    <a href="https://batipro63.fr/" rel="nofollow noopener noreferrer nofollow noopener noreferrer" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://batipro63.fr/&amp;source=gmail&amp;ust=1641478464356000&amp;usg=AOvVaw251Dn4DGxeXzy3xmQX4GmO">https://batipro63.fr/</a><br>
                                    <br>
                                    
                                </small>
                                        </p>


                                    </td>
                                </tr>
                            </tbody>
                        </table>

                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html><?php /**PATH /home/styve/dev/laravel/batipro/resources/views/mail/brochure.blade.php ENDPATH**/ ?>