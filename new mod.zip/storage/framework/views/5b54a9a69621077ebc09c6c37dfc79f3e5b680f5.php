<div>
    <div class="container flex space-around" >
        <span> site réalisé par <a href="mailto:referentdigital360@gmail.com" wire:click='mailme()'
            style="color: #5aa39c">referentdigital360@gmail.com</a> </span>
      </div>
</div>
<?php /**PATH /home/styve/dev/laravel/batipro/resources/views/livewire/mail-sty.blade.php ENDPATH**/ ?>