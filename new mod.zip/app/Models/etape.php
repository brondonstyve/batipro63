<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class etape extends Model
{
    use HasFactory;

    protected $fillable=[
        'titreEnt',
        'desciptionEn',
        'etape1',
        'titre1',
        'description1',
        'image1',
        'etape2',
        'titre2',
        'description2',
        'image2',
        'etape3',
        'titre3',
        'description3',
        'image3',
        'etape4',
        'titre4',
        'description4',
        'image4',
        'etape5',
        'titre5',
        'description5',
        'image5',
        'etape6',
        'titre6',
        'description6',
        'image6',
        'etape7',
        'titre7',
        'description7',
        'image7',
        'etape8',
        'titre8',
        'description8',
        'image8',
        'etape9',
        'titre9',
        'description9',
        'image9',
        'etape10',
        'titre10',
        'description10',
        'image10',
    ];
}
